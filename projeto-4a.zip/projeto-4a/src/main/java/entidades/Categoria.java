package entidades;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

public class Categoria extends PanacheEntityBase {
    
}
